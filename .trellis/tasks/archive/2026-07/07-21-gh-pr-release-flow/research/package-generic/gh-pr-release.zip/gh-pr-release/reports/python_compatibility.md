# Python Compatibility

Generated at: `2026-07-21T00:00:00Z`

## Summary

- decision: `pass`
- target python: `3.11`
- files scanned: `6`
- issues: `0`
- syntax errors: `0`
- f-string 3.11 violations: `0`

This report catches Python syntax and compatibility hazards that can pass on a newer local interpreter but fail in the supported CI/runtime interpreter.

## Issues

| Path | Line | Rule | Message |
| --- | ---: | --- | --- |
| `none` | 0 | `none` | none |
